import React from 'react';
import { View, Text, Button } from 'react-native';
import MainLayout from '../layouts/Mainlayout.jsx'; // Import the MainLayout component

function HomeScreen({ navigation }) {
  return (
    <MainLayout>
      <View>
        <Text>To-Do List</Text>
        {/* Display your to-do list component here */}
        {/* Display your to-do form component here */}
        
        <Button
          title="Go to About"
          onPress={() => navigation.navigate('About')}
        />
      </View>
    </MainLayout>
  );
}

export default HomeScreen;
