import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MainLayout from '../layouts/Mainlayout.jsx'; 

function AboutScreen() {
  const appName = "lab 5 Assignment"; // Replace with your app's name
  const yourName = "Abdul Al Sham"; // Replace with your name
  const currentDate = new Date().toDateString();

  return (
    <MainLayout>
      <View style={styles.container}>
        <Text style={styles.title}>About</Text>
        <Text style={styles.text}>App Name: {appName}</Text>
        <Text style={styles.text}>Author: {yourName}</Text>
        <Text style={styles.text}>Current Date: {currentDate}</Text>
      </View>
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  text: {
    fontSize: 16,
    marginBottom: 10,
  },
});

export default AboutScreen;
